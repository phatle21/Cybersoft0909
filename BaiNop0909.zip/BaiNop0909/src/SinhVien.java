import java.util.Scanner;

public class SinhVien {
	private String tenSinhVien;
	private String maSinhVien;
	private double diemToan;
	private double diemLy;
	private double diemHoa;
	
	public void nhap(Scanner sc) {
		System.out.println("Nhập tên sinh viên");
		tenSinhVien = sc.nextLine();
		System.out.println("Nhập mã sinh viên ");
		maSinhVien = sc.nextLine();
		System.out.println("Nhập điểm Toán ");
		diemToan = sc.nextDouble();
		System.out.println("Nhập điểm Lý");
		diemLy = sc.nextDouble();
		System.out.println("Nhập điểm Hóa");
		diemHoa = sc.nextDouble();
	}
	
	public String getTenSinhVien() {
		return tenSinhVien;
	}

	public void setTenSinhVien(String tenSinhVien) {
		this.tenSinhVien = tenSinhVien;
	}

	public String getMaSinhVien() {
		return maSinhVien;
	}

	public void setMaSinhVien(String maSinhVien) {
		this.maSinhVien = maSinhVien;
	}

	public double getDiemToan() {
		return diemToan;
	}

	public void setDiemToan(double diemToan) {
		this.diemToan = diemToan;
	}

	public double getDiemLy() {
		return diemLy;
	}

	public void setDiemLy(double diemLy) {
		this.diemLy = diemLy;
	}

	public double getDiemHoa() {
		return diemHoa;
	}

	public void setDiemHoa(double diemHoa) {
		this.diemHoa = diemHoa;
	}

	public double tinhDiemTrungBinh(double diemToan, double diemLy, double diemHoa) {
		double ketQua = (diemToan+diemLy+diemHoa)/3;
		return ketQua;
	}
	
	public void xepLoai(double dtb) {
		if(dtb >= 0 && dtb <= 10) {
			if(dtb >= 9) {
				System.out.println("Xuất sắc");
			}else if(dtb < 9 && dtb >= 8) {
				System.out.println("Giỏi");
			}else if(dtb < 8 && dtb >= 7) {
				System.out.println("Khá");
			}else if(dtb < 7 && dtb >= 6) {
				System.out.println("Trung bình khá");
			}else if(dtb < 6 && dtb >= 5) {
				System.out.println("Trung bình");
			}else {
				System.out.println("Yếu");
			}
		}
	}
}
