import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SinhVien sinhVien = new SinhVien();	
		ArrayList<SinhVien> listSV = new ArrayList<SinhVien>();
		listSV.add(sinhVien);
		for(SinhVien sv : listSV) {
			sv.nhap(new Scanner(System.in));
			double diemTrungBinh = sv.tinhDiemTrungBinh(sv.getDiemToan(), sv.getDiemLy(), sv.getDiemHoa());
			System.out.println("Điểm trung bình: " + diemTrungBinh);
			System.out.print("Xếp loại: " );
			sv.xepLoai(diemTrungBinh);
		}
		
	}

}
